To learn more about the font family and its license, visit https://www.fontmirror.com/terminus-ttf

Copyright (c) 2010 Dimitar Toshkov Zhekov,
with Reserved Font Name "Terminus Font".
 
Copyright (c) 2011 Tilman Blumenbach,
with Reserved Font Name "Terminus (TTF)".